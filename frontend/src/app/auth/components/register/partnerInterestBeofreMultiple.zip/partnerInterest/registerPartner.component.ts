import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormArray, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { RegisterPartnerService } from './registerPartner.service';
import { registerPartnerConfig } from './registerPartner.config'

@Component({
    selector: 'app-registerPartner',
    templateUrl: './registerPartner.component.html',
    styleUrls: ['./registerPartner.component.css']
})

export class registerPartnerComponent implements OnInit {
    multistep!: FormGroup;
    activeStepper: boolean = true;
    stepper2active: boolean = false;
    ifAdminPronounsActive: boolean = false;
    ifProfilePronounsActive: boolean = false;
    ifPrimaryPronounsActive: boolean = false;
    ifSecondaryPronounsActive: boolean = false;
    principalChecked: boolean = false;
    isMailDiff: boolean = false;
    isPrimarySupport: boolean = false;
    isSecondarySupport: boolean = false;
    config:any = registerPartnerConfig;
    ifnothearAboutusActive: boolean = false;
    isSpeakhireProgramSelected: boolean = false;
    hoverData: string;
    fyYearSelectedActive: boolean = false;
    yfYearFullSelectedActive: boolean = false;

    constructor(private cd: ChangeDetectorRef, private registerPartnerService: RegisterPartnerService) { }

    ngOnInit() {

        this.multistep = new FormGroup({
            partnerInformation: new FormGroup({
                partnerName: new FormControl('', [Validators.required, Validators.minLength(2)]),
                partnerLocation: new FormControl('', Validators.required),
                partner_streetAddress: new FormControl('', [Validators.required, Validators.minLength(2)]),
                partner_city: new FormControl('', [Validators.required, Validators.minLength(2)]),
                partner_state: new FormControl('', [Validators.required, Validators.minLength(2)]),
                partner_zipcode: new FormControl('', [Validators.required, Validators.minLength(2)]),
                partner_phoneCode: new FormControl('', Validators.required),
                partner_phone_number: new FormControl('', [Validators.required, Validators.pattern('^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$')]),
                partner_pNumberExtension: new FormControl(''),
                partner_country: new FormControl('', Validators.required),
            }),
            adminInformation: new FormGroup({
                confirmPrincipal: new FormControl(''),
                adminFname: new FormControl(null, [Validators.required, Validators.minLength(2)]),
                adminLname: new FormControl('', [Validators.required, Validators.minLength(2)]),
                adminJobTitle: new FormControl('', [Validators.required, Validators.minLength(3)]),
                adminForm_of_contact: new FormControl('', Validators.required),
                adminGender: new FormControl('', Validators.required),
                adminPNumberCode: new FormControl('', Validators.required),
                adminPNumber: new FormControl('', [Validators.required, Validators.pattern('^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$')]),
                adminpPNumberExtension: new FormControl(''),
                adminPreferred_pronouns: new FormControl('', [Validators.required, Validators.minLength(3)]),
                adminOtherPronouns: new FormControl('', [Validators.required, Validators.minLength(3)]),
                adminEmail: new FormControl(null, [Validators.required, Validators.email]),
            }),
            mailingAddressInformation: new FormGroup({
                confirmMailingAddress: new FormControl(''),
                streetAddress: new FormControl('', [Validators.required, Validators.minLength(2)]),
                city: new FormControl('', [Validators.required, Validators.minLength(2)]),
                state: new FormControl('', [Validators.required, Validators.minLength(2)]),
                zipcode: new FormControl('', [Validators.required, Validators.minLength(2)]),
                country: new FormControl('', Validators.required),
            }),
            primarySupportLiasonInformation: new FormGroup({
                confirmPrimarySuport: new FormControl(''),
                primarySuportFname: new FormControl(null, [Validators.required, Validators.minLength(2)]),
                primarySuportLname: new FormControl('', [Validators.required, Validators.minLength(2)]),
                primarySuportJobTitle: new FormControl('', [Validators.required, Validators.minLength(3)]),
                primarySuportForm_of_contact: new FormControl('', Validators.required),
                primarySuportGender: new FormControl('', Validators.required),
                primarySuportPNumberCode: new FormControl(''),
                primarySuportPNumber: new FormControl('', [Validators.required, Validators.pattern('^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$')]),
                primarySuportPNumberExtension: new FormControl(''),
                primarySuportPreferred_pronouns: new FormControl('', [Validators.required, Validators.minLength(3)]),
                primaryOtherPronouns: new FormControl('', [Validators.required, Validators.minLength(3)]),
                primarySuportEmail: new FormControl(null, [Validators.required, Validators.email]),
            }),
            secondarySupportLiasonInformation: new FormGroup({
                confirmSecondarySuport: new FormControl(''),
                secondarySuportFname: new FormControl(null, [Validators.required, Validators.minLength(2)]),
                secondarySuportLname: new FormControl('', [Validators.required, Validators.minLength(2)]),
                secondarySuportJobTitle: new FormControl('', [Validators.required, Validators.minLength(3)]),
                secondarySuportForm_of_contact: new FormControl('', Validators.required),
                secondarySuportGender: new FormControl('', Validators.required),
                secondarySuportPNumberCode: new FormControl(''),
                secondarySuportPNumber: new FormControl('', [Validators.required, Validators.pattern('^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$')]),
                secondarySuportPNumberExtension: new FormControl(''),
                secondarySuportPreferred_pronouns: new FormControl('', [Validators.required, Validators.minLength(3)]),
                secondaryOtherPronouns: new FormControl('', [Validators.required, Validators.minLength(3)]),
                secondarySuportEmail: new FormControl(null, [Validators.required, Validators.email]),
            }),
            profileInformation: new FormGroup({
                fname: new FormControl(null, [Validators.required, Validators.minLength(2)]),
                lname: new FormControl('', [Validators.required, Validators.minLength(2)]),
                jobTitle: new FormControl('', [Validators.required, Validators.minLength(3)]),
                form_of_contact: new FormControl('', Validators.required),
                gender: new FormControl('', Validators.required),
                pNumberCode: new FormControl(''),
                pNumber: new FormControl('', [Validators.required, Validators.pattern('^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$')]),
                pNumberExtension: new FormControl(''),
                preferred_pronouns: new FormControl('', [Validators.required, Validators.minLength(3)]),
                other_pronouns: new FormControl('', [Validators.required, Validators.minLength(3)]),
                email: new FormControl(null, [Validators.required, Validators.email]),
            }),
            demographicInformation: new FormGroup({
                totalPopulationServed: new FormControl('', Validators.required),
                percentageOfLowIncome: new FormControl('', Validators.required),
                genderBreakdown: new FormControl('', [Validators.required]),
                percentageOfEllMll: new FormControl('', Validators.required),
                languageNeeds: new FormControl('', Validators.required),
                percentageOfMinority: new FormControl('', [Validators.required]),
                ethnicBreakdown: new FormControl('', [Validators.required]),
                districtNetworkContact: new FormControl(''),
            }),
            speakhirePrograms1: new FormGroup({
                interestedProgram: new FormArray([], Validators.required),
                fyStudentConsideration: new FormControl(''),
                fyFullChapterActivities: new FormControl(''),
            }),
            speakhirePrograms2: new FormGroup({
                programFunds: new FormControl('', Validators.required),
                philadelphiaPartnerships: new FormControl(''),
                advisoryPeriodBool: new FormControl('', [Validators.required]),
                iUnderstand: new FormControl('', Validators.required),
            }),
            getToKnowYou: new FormGroup({
                personInterests: new FormControl('', Validators.required),
                howToSupportYou: new FormControl('', Validators.required),
                howToHelpStudents: new FormControl('', Validators.required),
                howToHelpPartner: new FormControl('', [Validators.required]),
                hearAboutUs: new FormControl('', Validators.required),
                ifnothearAboutus: new FormControl(''),
                questionsComments: new FormControl(''),
            }),
            thankyou: new FormGroup({
                thanks: new FormControl(),
            }),
        })
        this.multistep.get('getToKnowYou')?.get('hearAboutUs')?.valueChanges.subscribe(res=>{
            if(res==='Other'){
                this.ifnothearAboutusActive = true;
            } else {
                this.ifnothearAboutusActive = false;
            }
        })
        this.multistep.get('adminInformation')?.get('adminPreferred_pronouns')?.valueChanges.subscribe(res=>{
            if(res==='Other'){
                this.ifAdminPronounsActive = true;
            } else {
                this.ifAdminPronounsActive = false;
            }
        })
        this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportPreferred_pronouns')?.valueChanges.subscribe(res=>{
            if(res==='Other'){
                this.ifPrimaryPronounsActive = true;
            } else {
                this.ifPrimaryPronounsActive = false;
            }
        })
        this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportPreferred_pronouns')?.valueChanges.subscribe(res=>{
            if(res==='Other'){
                this.ifSecondaryPronounsActive = true;
            } else {
                this.ifSecondaryPronounsActive = false;
            }
        })
        this.multistep.get('profileInformation')?.get('preferred_pronouns')?.valueChanges.subscribe(res=>{
            if(res==='Other'){
                this.ifProfilePronounsActive = true;
            } else {
                this.ifProfilePronounsActive = false;
            }
        })
        // this.multistep.get('profileInformation')?.get('preferred_pronouns')?.valueChanges.subscribe(res=>{
        //     if(res==='Other'){
        //         this.ifProfilePronounsActive = true;
        //     } else {
        //         this.ifProfilePronounsActive = false;
        //     }
        // })

    }
    submitPartner() {
        this.registerPartnerService.getPartner(this.multistep.value).subscribe(res => {
            console.log(res)
        },
            err => {
                console.log(err)
                //show the errors here 
            })
    }

    // partnerInformation
    get partnerName() { return this.multistep.get('partnerInformation')?.get('partnerName'); }
    get partnerLocation() { return this.multistep.get('partnerInformation')?.get('partnerLocation'); }
    get partner_streetAddress() { return this.multistep.get('partnerInformation')?.get('partner_streetAddress'); }
    get partner_city() { return this.multistep.get('partnerInformation')?.get('partner_city'); }
    get partner_state() { return this.multistep.get('partnerInformation')?.get('partner_state'); }
    get partner_zipcode() { return this.multistep.get('partnerInformation')?.get('partner_zipcode'); }
    get partner_phoneCode() { return this.multistep.get('partnerInformation')?.get('partner_phoneCode'); }
    get partner_phone_number() { return this.multistep.get('partnerInformation')?.get('partner_phone_number'); }
    get partner_pNumberExtension() { return this.multistep.get('partnerInformation')?.get('partner_pNumberExtension'); }
    get partner_country() { return this.multistep.get('partnerInformation')?.get('partner_country'); }

    // adminInformation
    get confirmPrincipal() { return this.multistep.get('adminInformation')?.get('confirmPrincipal'); }
    get adminFname() { return this.multistep.get('adminInformation')?.get('adminFname'); }
    get adminLname() { return this.multistep.get('adminInformation')?.get('adminLname'); }
    get adminJobTitle() { return this.multistep.get('adminInformation')?.get('adminJobTitle'); }
    get adminForm_of_contact() { return this.multistep.get('adminInformation')?.get('adminForm_of_contact'); }
    get adminGender() { return this.multistep.get('adminInformation')?.get('adminGender'); }
    get adminPNumberCode() { return this.multistep.get('adminInformation')?.get('adminPNumberCode'); }
    get adminPNumber() { return this.multistep.get('adminInformation')?.get('adminPNumber'); }
    get adminpPNumberExtension() { return this.multistep.get('adminInformation')?.get('adminpPNumberExtension'); }
    get adminPreferred_pronouns() { return this.multistep.get('adminInformation')?.get('adminPreferred_pronouns'); }
    get adminOtherPronouns() { return this.multistep.get('adminInformation')?.get('adminOtherPronouns'); }
    get adminEmail() { return this.multistep.get('adminInformation')?.get('adminEmail'); }

    // mailingAddressInformation
    get confirmMailingAddress() { return this.multistep.get('mailingAddressInformation')?.get('confirmMailingAddress'); }
    get streetAddress() { return this.multistep.get('mailingAddressInformation')?.get('streetAddress'); }
    get city() { return this.multistep.get('mailingAddressInformation')?.get('city'); }
    get state() { return this.multistep.get('mailingAddressInformation')?.get('state'); }
    get zipcode() { return this.multistep.get('mailingAddressInformation')?.get('zipcode'); }
    get country() { return this.multistep.get('mailingAddressInformation')?.get('country'); }

    // primarySupportLiasonInformation
    get confirmPrimarySuport() { return this.multistep.get('primarySupportLiasonInformation')?.get('confirmPrimarySuport'); }
    get primarySuportFname() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportFname'); }
    get primarySuportLname() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportLname'); }
    get primarySuportJobTitle() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportJobTitle'); }
    get primarySuportForm_of_contact() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportForm_of_contact'); }
    get primarySuportGender() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportGender'); }
    get primarySuportPNumberCode() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportPNumberCode'); }
    get primarySuportPNumber() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportPNumber'); }
    get primarySuportPNumberExtension() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportPNumberExtension'); }
    get primarySuportPreferred_pronouns() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportPreferred_pronouns'); }
    get primaryOtherPronouns() { return this.multistep.get('primarySupportLiasonInformation')?.get('primaryOtherPronouns'); }
    get primarySuportEmail() { return this.multistep.get('primarySupportLiasonInformation')?.get('primarySuportEmail'); }

    // secondarySupportLiasonInformation
    get confirmSecondarySuport() { return this.multistep.get('secondarySupportLiasonInformation')?.get('confirmSecondarySuport'); }
    get secondarySuportFname() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportFname'); }
    get secondarySuportLname() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportLname'); }
    get secondarySuportJobTitle() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportJobTitle'); }
    get secondarySuportForm_of_contact() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportForm_of_contact'); }
    get secondarySuportGender() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportGender'); }
    get secondarySuportPNumberCode() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportPNumberCode'); }
    get secondarySuportPNumber() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportPNumber'); }
    get secondarySuportPNumberExtension() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportPNumberExtension'); }
    get secondarySuportPreferred_pronouns() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportPreferred_pronouns'); }
    get secondaryOtherPronouns() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondaryOtherPronouns'); }
    get secondarySuportEmail() { return this.multistep.get('secondarySupportLiasonInformation')?.get('secondarySuportEmail'); }

    // profileInformation
    get fname() { return this.multistep.get('profileInformation')?.get('fname'); }
    get lname() { return this.multistep.get('profileInformation')?.get('lname'); }
    get jobTitle() { return this.multistep.get('profileInformation')?.get('jobTitle'); }
    get form_of_contact() { return this.multistep.get('profileInformation')?.get('form_of_contact'); }
    get gender() { return this.multistep.get('profileInformation')?.get('gender'); }
    get pNumberCode() { return this.multistep.get('profileInformation')?.get('pNumberCode'); }
    get pNumber() { return this.multistep.get('profileInformation')?.get('pNumber'); }
    get pNumberExtension() { return this.multistep.get('profileInformation')?.get('pNumberExtension'); }
    get preferred_pronouns() { return this.multistep.get('profileInformation')?.get('preferred_pronouns'); }
    get other_pronouns() { return this.multistep.get('profileInformation')?.get('other_pronouns'); }
    get email() { return this.multistep.get('profileInformation')?.get('email'); }

    // demographicInformation
    get totalPopulationServed() { return this.multistep.get('demographicInformation')?.get('totalPopulationServed'); }
    get percentageOfLowIncome() { return this.multistep.get('demographicInformation')?.get('percentageOfLowIncome'); }
    get genderBreakdown() { return this.multistep.get('demographicInformation')?.get('genderBreakdown'); }
    get percentageOfEllMll() { return this.multistep.get('demographicInformation')?.get('percentageOfEllMll'); }
    get languageNeeds() { return this.multistep.get('demographicInformation')?.get('languageNeeds'); }
    get percentageOfMinority() { return this.multistep.get('demographicInformation')?.get('percentageOfMinority'); }
    get ethnicBreakdown() { return this.multistep.get('demographicInformation')?.get('ethnicBreakdown'); }
    get districtNetworkContact() { return this.multistep.get('demographicInformation')?.get('districtNetworkContact'); }

    // speakhirePrograms1
    get interestedProgramsß() { return this.multistep.get('speakhirePrograms1')?.get('interestedProgram'); }
    get fyStudentConsideration() { return this.multistep.get('speakhirePrograms1')?.get('fyStudentConsideration'); }
    get fyFullChapterActivities() { return this.multistep.get('speakhirePrograms1')?.get('fyFullChapterActivities'); }

    // speakhirePrograms2

    get programFunds() { return this.multistep.get('speakhirePrograms2')?.get('programFunds'); }
    get philadelphiaPartnerships() { return this.multistep.get('speakhirePrograms2')?.get('philadelphiaPartnerships'); }
    get advisoryPeriodBool() { return this.multistep.get('speakhirePrograms2')?.get('advisoryPeriodBool'); }
    get iUnderstand() { return this.multistep.get('speakhirePrograms2')?.get('iUnderstand'); }

    // getToKnowYou
    get personInterests() { return this.multistep.get('getToKnowYou')?.get('personInterests'); }
    get howToSupportYou() { return this.multistep.get('getToKnowYou')?.get('howToSupportYou'); }
    get howToHelpStudents() { return this.multistep.get('getToKnowYou')?.get('howToHelpStudents'); }
    get howToHelpPartner() { return this.multistep.get('getToKnowYou')?.get('howToHelpPartner'); }
    get hearAboutUs() { return this.multistep.get('getToKnowYou')?.get('hearAboutUs'); }
    get ifnothearAboutus() { return this.multistep.get('getToKnowYou')?.get('ifnothearAboutus'); }
    get questionsComments() { return this.multistep.get('getToKnowYou')?.get('questionsComments'); }

    checkboxChanged(event: any) {
        this.principalChecked = event.checked
    }

    differentMail(event: any) {
        this.isMailDiff = event.checked
    }

    validate(form: string, check?: boolean) {
        if ((form === "profileInformation") && check) {
            return false
        } else if (form === 'mailingAddressInformation' && !this.isMailDiff) {
            return true
        } else if(form === 'primarySupportLiasonInformation' && !this.isPrimarySupport){
          return true
        } else if(form === 'secondarySupportLiasonInformation' && !this.isSecondarySupport){
          return true
        } else if(form === 'speakhirePrograms1' && !this.isSpeakhireProgramSelected){
          return true
        }
        for (const field in this.multistep.get(form)?.value) { // 'field' is a string
            if (!this.multistep.get(form)?.get(field)?.valid) {
                return false
            }
        }
        return true
    }

    checkStepper(toggleFlag: boolean) {
        if (toggleFlag) {
            this.activeStepper = true;
            this.stepper2active = true;
        } else {
            this.activeStepper = false;
            this.stepper2active = false;
        }
    }

    checkIfPrimarySupport(event: any) {
        this.isPrimarySupport = event.checked
        // if(this.isPrimarySupport){
        //     this.multistep.get('primarySupportLiasonInformation')?.patchValue({
        //         primarySuportFname: this.adminFname?.value,
        //         primarySuportLname: this.adminLname?.value,
        //         primarySuportJobTitle: this.adminJobTitle?.value,
        //         primarySuportForm_of_contact: this.adminForm_of_contact?.value,
        //         primarySuportGender: this.adminGender?.value,
        //         primarySuportPNumber: this.adminPNumber?.value,
        //         primarySuportPNumberExtension: this.adminpPNumberExtension?.value,
        //         primarySuportPreferred_pronouns: this.adminPreferred_pronouns?.value,
        //         primarySuportEmail: this.adminEmail?.value
        //     })
        // } else {
        //     this.multistep.get('primarySupportLiasonInformation')?.reset()
        // }
    }

    checkIfSecondarySupport(event: any) {
        this.isSecondarySupport = event.checked
        // if(this.isSecondarySupport){
        //     this.multistep.get('secondarySupportLiasonInformation')?.patchValue({
        //         secondarySuportFname: this.adminFname?.value,
        //         secondarySuportLname: this.adminLname?.value,
        //         secondarySuportJobTitle: this.adminJobTitle?.value,
        //         secondarySuportForm_of_contact: this.adminForm_of_contact?.value,
        //         secondarySuportGender: this.adminGender?.value,
        //         secondarySuportPNumber: this.adminPNumber?.value,
        //         secondarySuportPNumberExtension: this.adminpPNumberExtension?.value,
        //         secondarySuportPreferred_pronouns: this.adminPreferred_pronouns?.value,
        //         secondarySuportEmail: this.adminEmail?.value
        //     })
        // } else {
        //     this.multistep.get('primarySupportLiasonInformation')?.reset()
        // }
    }

    checkIfSpeakhireProgram(event: any) {
        this.isSecondarySupport = event.checked
    }

    showErrors(form: string) {
        for (const field in this.multistep.get(form)?.value) {
            if (!this.multistep.get(form)?.get(field)?.touched && this.multistep.get(form)?.get(field)?.invalid) {
                this.multistep.get(form)?.get(field)?.markAllAsTouched()
            }
        }
        return true
    }

    mouseOverRow(hoverText: any){
        this.hoverData = hoverText
    }
    mouseLeaveRow(){
        this.hoverData = 'Please choose one of the following options to read up on the details'
    }

    onCheckboxChange(e: any) {
        const interestedProgram: FormArray = this.multistep.get('speakhirePrograms1')?.get('interestedProgram') as FormArray;
    
        if (e.target.checked) {
            interestedProgram.push(new FormControl(e.target.value));
        } else {
          let i: number = 0;
          interestedProgram.controls.forEach((item) => {
            if (item.value == e.target.value) {
                interestedProgram.removeAt(i);
              return;
            }
            i++;
          });
        }
      }
}